
import 'dart:typed_data';
import 'package:flutter/services.dart';
import 'package:image/image.dart' as img;
import 'package:tflite_flutter/tflite_flutter.dart';

class Prediction {
  final String label;
  final double confidence;

  Prediction(this.label, this.confidence);
}

List<String> parseLabels(String raw) {
  return raw
      .split('\n')
      .where((line) => line.trim().isNotEmpty)
      .map((line) => line.trim().replaceFirst(
            RegExp(r'^\d+\s+'), '',
          ))
      .toList();
}

class Classifier {
  final Interpreter interpreter;
  final List<String> labels;

  static const int inputSize = 224;

  Classifier(this.interpreter, this.labels);

  static Future<Classifier> load() async {
    final interpreter = await Interpreter.fromAsset(
      'assets/model/model_unquant.tflite',
    );

    final rawLabels = await rootBundle.loadString(
      'assets/model/labels.txt',
    );

    final labels = parseLabels(rawLabels);

    return Classifier(interpreter, labels);
  }

  List<Prediction> classify(Uint8List bytes) {
    final decoded = img.decodeImage(bytes);

    if (decoded == null) {
      throw const FormatException('Invalid image');
    }

    final square = img.copyResizeCropSquare(
      img.bakeOrientation(decoded),
      size: inputSize,
    );

    final input = [
      List.generate(inputSize, (y) {
        return List.generate(inputSize, (x) {
          final pixel = square.getPixel(x, y);

          return [
            pixel.r.toDouble() / 127.5 - 1,
            pixel.g.toDouble() / 127.5 - 1,
            pixel.b.toDouble() / 127.5 - 1,
          ];
        });
      }),
    ];

    final output = [
      List<double>.filled(labels.length, 0),
    ];

    interpreter.run(input, output);

    final predictions = [
      for (int i = 0; i < labels.length; i++)
        Prediction(labels[i], output[0][i]),
    ];

    predictions.sort(
      (a, b) => b.confidence.compareTo(a.confidence),
    );

    return predictions;
  }

  void close() {
    interpreter.close();
  }
}
