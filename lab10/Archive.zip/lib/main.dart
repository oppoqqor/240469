
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'services/classifier.dart';

void main() {
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: ModelTestScreen(),
  ));
}

class ModelTestScreen extends StatefulWidget {
  const ModelTestScreen({super.key});

  @override
  State<ModelTestScreen> createState() => _ModelTestScreenState();
}

class _ModelTestScreenState extends State<ModelTestScreen> {
  String result = 'Loading model...';

  @override
  void initState() {
    super.initState();
    testModel();
  }

  Future<void> testModel() async {
    Classifier? classifier;

    try {
      classifier = await Classifier.load();

      final data = await rootBundle.load(
        'assets/model/sample.jpg',
      );

      final predictions = classifier.classify(
        data.buffer.asUint8List(),
      );

      if (!mounted) return;

      setState(() {
        result = predictions.map((p) {
          return '${p.label}: '
              '${(p.confidence * 100).toStringAsFixed(1)}%';
        }).join('\n\n');
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        result = 'Error: $e';
      });
    } finally {
      classifier?.close();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('AI Model Test'),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text(
            result,
            style: const TextStyle(fontSize: 20),
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }
}
